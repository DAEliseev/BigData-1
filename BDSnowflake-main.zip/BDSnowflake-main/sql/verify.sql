SELECT 'staging.mock_data' AS table_name, COUNT(*) AS rows FROM staging.mock_data
UNION ALL SELECT 'dw.fact_sales', COUNT(*) FROM dw.fact_sales
UNION ALL SELECT 'dw.dim_customer', COUNT(*) FROM dw.dim_customer
UNION ALL SELECT 'dw.dim_seller', COUNT(*) FROM dw.dim_seller
UNION ALL SELECT 'dw.dim_product', COUNT(*) FROM dw.dim_product
UNION ALL SELECT 'dw.dim_store', COUNT(*) FROM dw.dim_store
UNION ALL SELECT 'dw.dim_supplier', COUNT(*) FROM dw.dim_supplier
UNION ALL SELECT 'dw.dim_country', COUNT(*) FROM dw.dim_country
UNION ALL SELECT 'dw.dim_date', COUNT(*) FROM dw.dim_date;

SELECT
    f.sale_sk,
    f.sale_total_price,
    cu.first_name || ' ' || cu.last_name AS customer_name,
    pc.postal_code,
    co.country_name
FROM dw.fact_sales f
JOIN dw.dim_customer cu ON cu.customer_sk = f.customer_sk
LEFT JOIN dw.dim_postal_code pc ON pc.postal_sk = cu.postal_sk
LEFT JOIN dw.dim_country co ON co.country_sk = pc.country_sk
LIMIT 5;

SELECT
    f.sale_sk,
    pr.product_name,
    cat.product_category,
    br.brand_name,
    sup.supplier_name,
    ci.city_name,
    co.country_name
FROM dw.fact_sales f
JOIN dw.dim_product pr ON pr.product_sk = f.product_sk
JOIN dw.dim_product_category cat ON cat.category_sk = pr.category_sk
JOIN dw.dim_brand br ON br.brand_sk = pr.brand_sk
LEFT JOIN dw.dim_supplier sup ON sup.supplier_sk = pr.supplier_sk
LEFT JOIN dw.dim_address ad ON ad.address_sk = sup.address_sk
LEFT JOIN dw.dim_city ci ON ci.city_sk = ad.city_sk
LEFT JOIN dw.dim_country co ON co.country_sk = ci.country_sk
LIMIT 5;
