CREATE SCHEMA IF NOT EXISTS dw;

CREATE TABLE dw.dim_country (
    country_sk    SERIAL PRIMARY KEY,
    country_name  VARCHAR(100) NOT NULL,
    CONSTRAINT uq_dim_country_name UNIQUE (country_name)
);

CREATE TABLE dw.dim_region (
    region_sk     SERIAL PRIMARY KEY,
    region_name   VARCHAR(100) NOT NULL,
    country_sk    INTEGER NOT NULL REFERENCES dw.dim_country (country_sk),
    CONSTRAINT uq_dim_region UNIQUE (region_name, country_sk)
);

CREATE TABLE dw.dim_city (
    city_sk       SERIAL PRIMARY KEY,
    city_name     VARCHAR(150) NOT NULL,
    region_sk     INTEGER REFERENCES dw.dim_region (region_sk),
    country_sk    INTEGER NOT NULL REFERENCES dw.dim_country (country_sk),
    CONSTRAINT uq_dim_city UNIQUE (city_name, region_sk, country_sk)
);

CREATE TABLE dw.dim_postal_code (
    postal_sk     SERIAL PRIMARY KEY,
    postal_code   VARCHAR(50) NOT NULL,
    country_sk    INTEGER NOT NULL REFERENCES dw.dim_country (country_sk),
    CONSTRAINT uq_dim_postal UNIQUE (postal_code, country_sk)
);

CREATE TABLE dw.dim_address (
    address_sk    SERIAL PRIMARY KEY,
    address_line  VARCHAR(255) NOT NULL,
    city_sk       INTEGER NOT NULL REFERENCES dw.dim_city (city_sk),
    CONSTRAINT uq_dim_address UNIQUE (address_line, city_sk)
);

CREATE TABLE dw.dim_product_category (
    category_sk       SERIAL PRIMARY KEY,
    product_category  VARCHAR(100) NOT NULL,
    pet_category      VARCHAR(100) NOT NULL,
    CONSTRAINT uq_dim_product_category UNIQUE (product_category, pet_category)
);

CREATE TABLE dw.dim_brand (
    brand_sk      SERIAL PRIMARY KEY,
    brand_name    VARCHAR(100) NOT NULL,
    CONSTRAINT uq_dim_brand_name UNIQUE (brand_name)
);

CREATE TABLE dw.dim_material (
    material_sk   SERIAL PRIMARY KEY,
    material_name VARCHAR(100) NOT NULL,
    CONSTRAINT uq_dim_material_name UNIQUE (material_name)
);

CREATE TABLE dw.dim_supplier (
    supplier_sk       SERIAL PRIMARY KEY,
    supplier_name     VARCHAR(150) NOT NULL,
    supplier_contact  VARCHAR(200),
    supplier_email    VARCHAR(200),
    supplier_phone    VARCHAR(50),
    address_sk        INTEGER REFERENCES dw.dim_address (address_sk),
    CONSTRAINT uq_dim_supplier UNIQUE (supplier_name, supplier_email)
);

CREATE TABLE dw.dim_product (
    product_sk          SERIAL PRIMARY KEY,
    product_name        VARCHAR(200) NOT NULL,
    unit_price          NUMERIC(12, 2),
    stock_quantity      INTEGER,
    product_weight      NUMERIC(10, 2),
    product_color       VARCHAR(50),
    product_size        VARCHAR(50),
    product_description TEXT,
    product_rating      NUMERIC(4, 1),
    product_reviews     INTEGER,
    release_date        DATE,
    expiry_date         DATE,
    category_sk         INTEGER REFERENCES dw.dim_product_category (category_sk),
    brand_sk            INTEGER REFERENCES dw.dim_brand (brand_sk),
    material_sk         INTEGER REFERENCES dw.dim_material (material_sk),
    supplier_sk         INTEGER REFERENCES dw.dim_supplier (supplier_sk),
    CONSTRAINT uq_dim_product_natural UNIQUE (product_name, brand_sk, category_sk)
);

CREATE TABLE dw.dim_customer (
    customer_sk         SERIAL PRIMARY KEY,
    first_name          VARCHAR(100),
    last_name           VARCHAR(100),
    age                 INTEGER,
    email               VARCHAR(200) NOT NULL,
    pet_type            VARCHAR(50),
    pet_name            VARCHAR(100),
    pet_breed           VARCHAR(100),
    postal_sk           INTEGER REFERENCES dw.dim_postal_code (postal_sk),
    CONSTRAINT uq_dim_customer_email UNIQUE (email)
);

CREATE TABLE dw.dim_seller (
    seller_sk       SERIAL PRIMARY KEY,
    first_name      VARCHAR(100),
    last_name       VARCHAR(100),
    email           VARCHAR(200) NOT NULL,
    postal_sk       INTEGER REFERENCES dw.dim_postal_code (postal_sk),
    CONSTRAINT uq_dim_seller_email UNIQUE (email)
);

CREATE TABLE dw.dim_store (
    store_sk        SERIAL PRIMARY KEY,
    store_name      VARCHAR(150) NOT NULL,
    store_location  VARCHAR(255),
    store_phone     VARCHAR(50),
    store_email     VARCHAR(200),
    city_sk         INTEGER REFERENCES dw.dim_city (city_sk),
    CONSTRAINT uq_dim_store UNIQUE (store_name, store_location, store_phone)
);

CREATE TABLE dw.dim_date (
    date_sk       INTEGER PRIMARY KEY,
    full_date     DATE NOT NULL UNIQUE,
    year          SMALLINT NOT NULL,
    quarter       SMALLINT NOT NULL,
    month         SMALLINT NOT NULL,
    day           SMALLINT NOT NULL,
    day_of_week   SMALLINT NOT NULL,
    month_name    VARCHAR(20) NOT NULL,
    is_weekend    BOOLEAN NOT NULL
);

CREATE TABLE dw.fact_sales (
    sale_sk           BIGSERIAL PRIMARY KEY,
    load_id           BIGINT NOT NULL UNIQUE REFERENCES staging.mock_data (load_id),
    source_file       TEXT NOT NULL,
    source_sale_id    INTEGER NOT NULL,
    date_sk           INTEGER NOT NULL REFERENCES dw.dim_date (date_sk),
    customer_sk       INTEGER NOT NULL REFERENCES dw.dim_customer (customer_sk),
    seller_sk         INTEGER NOT NULL REFERENCES dw.dim_seller (seller_sk),
    product_sk        INTEGER NOT NULL REFERENCES dw.dim_product (product_sk),
    store_sk          INTEGER NOT NULL REFERENCES dw.dim_store (store_sk),
    sale_quantity     INTEGER NOT NULL,
    sale_total_price  NUMERIC(12, 2) NOT NULL,
    unit_price        NUMERIC(12, 2),
    CONSTRAINT uq_fact_sales_source UNIQUE (source_file, source_sale_id)
);

CREATE INDEX idx_fact_sales_date ON dw.fact_sales (date_sk);
CREATE INDEX idx_fact_sales_customer ON dw.fact_sales (customer_sk);
CREATE INDEX idx_fact_sales_product ON dw.fact_sales (product_sk);
