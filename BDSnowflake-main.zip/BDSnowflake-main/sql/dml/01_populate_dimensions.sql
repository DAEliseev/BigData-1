CREATE OR REPLACE FUNCTION staging.nullif_blank(value TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
AS $$
    SELECT NULLIF(BTRIM(value), '');
$$;

CREATE OR REPLACE FUNCTION staging.parse_us_date(value TEXT)
RETURNS DATE
LANGUAGE plpgsql
IMMUTABLE
AS $$
BEGIN
    IF staging.nullif_blank(value) IS NULL THEN
        RETURN NULL;
    END IF;
    RETURN TO_DATE(value, 'MM/DD/YYYY');
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;

INSERT INTO dw.dim_country (country_name)
SELECT DISTINCT staging.nullif_blank(country_name)
FROM (
    SELECT customer_country AS country_name FROM staging.mock_data
    UNION
    SELECT seller_country FROM staging.mock_data
    UNION
    SELECT store_country FROM staging.mock_data
    UNION
    SELECT supplier_country FROM staging.mock_data
) src
WHERE staging.nullif_blank(country_name) IS NOT NULL
ON CONFLICT (country_name) DO NOTHING;

INSERT INTO dw.dim_region (region_name, country_sk)
SELECT DISTINCT
    staging.nullif_blank(m.store_state),
    c.country_sk
FROM staging.mock_data m
JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.store_country)
WHERE staging.nullif_blank(m.store_state) IS NOT NULL
ON CONFLICT (region_name, country_sk) DO NOTHING;

INSERT INTO dw.dim_city (city_name, region_sk, country_sk)
SELECT DISTINCT
    staging.nullif_blank(m.store_city),
    r.region_sk,
    c.country_sk
FROM staging.mock_data m
JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.store_country)
LEFT JOIN dw.dim_region r
  ON r.region_name = staging.nullif_blank(m.store_state)
 AND r.country_sk = c.country_sk
WHERE staging.nullif_blank(m.store_city) IS NOT NULL
ON CONFLICT (city_name, region_sk, country_sk) DO NOTHING;

INSERT INTO dw.dim_city (city_name, region_sk, country_sk)
SELECT DISTINCT
    staging.nullif_blank(m.supplier_city),
    NULL::INTEGER,
    c.country_sk
FROM staging.mock_data m
JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.supplier_country)
WHERE staging.nullif_blank(m.supplier_city) IS NOT NULL
ON CONFLICT (city_name, region_sk, country_sk) DO NOTHING;

INSERT INTO dw.dim_postal_code (postal_code, country_sk)
SELECT DISTINCT
    staging.nullif_blank(m.customer_postal_code),
    c.country_sk
FROM staging.mock_data m
JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.customer_country)
WHERE staging.nullif_blank(m.customer_postal_code) IS NOT NULL
ON CONFLICT (postal_code, country_sk) DO NOTHING;

INSERT INTO dw.dim_postal_code (postal_code, country_sk)
SELECT DISTINCT
    staging.nullif_blank(m.seller_postal_code),
    c.country_sk
FROM staging.mock_data m
JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.seller_country)
WHERE staging.nullif_blank(m.seller_postal_code) IS NOT NULL
ON CONFLICT (postal_code, country_sk) DO NOTHING;

INSERT INTO dw.dim_address (address_line, city_sk)
SELECT DISTINCT
    staging.nullif_blank(m.supplier_address),
    ci.city_sk
FROM staging.mock_data m
JOIN dw.dim_country co
  ON co.country_name = staging.nullif_blank(m.supplier_country)
JOIN dw.dim_city ci
  ON ci.city_name = staging.nullif_blank(m.supplier_city)
 AND ci.country_sk = co.country_sk
 AND ci.region_sk IS NULL
WHERE staging.nullif_blank(m.supplier_address) IS NOT NULL
ON CONFLICT (address_line, city_sk) DO NOTHING;

INSERT INTO dw.dim_product_category (product_category, pet_category)
SELECT DISTINCT
    COALESCE(staging.nullif_blank(product_category), 'Unknown'),
    COALESCE(staging.nullif_blank(pet_category), 'Unknown')
FROM staging.mock_data
ON CONFLICT (product_category, pet_category) DO NOTHING;

INSERT INTO dw.dim_brand (brand_name)
SELECT DISTINCT COALESCE(staging.nullif_blank(product_brand), 'Unknown')
FROM staging.mock_data
ON CONFLICT (brand_name) DO NOTHING;

INSERT INTO dw.dim_material (material_name)
SELECT DISTINCT COALESCE(staging.nullif_blank(product_material), 'Unknown')
FROM staging.mock_data
ON CONFLICT (material_name) DO NOTHING;

INSERT INTO dw.dim_supplier (
    supplier_name, supplier_contact, supplier_email, supplier_phone, address_sk
)
SELECT DISTINCT ON (
    staging.nullif_blank(m.supplier_name),
    staging.nullif_blank(m.supplier_email)
)
    staging.nullif_blank(m.supplier_name),
    staging.nullif_blank(m.supplier_contact),
    staging.nullif_blank(m.supplier_email),
    staging.nullif_blank(m.supplier_phone),
    a.address_sk
FROM staging.mock_data m
LEFT JOIN dw.dim_country co
  ON co.country_name = staging.nullif_blank(m.supplier_country)
LEFT JOIN dw.dim_city ci
  ON ci.city_name = staging.nullif_blank(m.supplier_city)
 AND ci.country_sk = co.country_sk
 AND ci.region_sk IS NULL
LEFT JOIN dw.dim_address a
  ON a.address_line = staging.nullif_blank(m.supplier_address)
 AND a.city_sk = ci.city_sk
WHERE staging.nullif_blank(m.supplier_name) IS NOT NULL
ORDER BY
    staging.nullif_blank(m.supplier_name),
    staging.nullif_blank(m.supplier_email),
    m.load_id
ON CONFLICT (supplier_name, supplier_email) DO NOTHING;

INSERT INTO dw.dim_product (
    product_name, unit_price, stock_quantity, product_weight,
    product_color, product_size, product_description, product_rating,
    product_reviews, release_date, expiry_date, category_sk, brand_sk,
    material_sk, supplier_sk
)
SELECT DISTINCT ON (
    staging.nullif_blank(m.product_name),
    br.brand_sk,
    cat.category_sk
)
    staging.nullif_blank(m.product_name),
    NULLIF(m.product_price, '')::NUMERIC(12, 2),
    NULLIF(m.product_quantity, '')::INTEGER,
    NULLIF(m.product_weight, '')::NUMERIC(10, 2),
    staging.nullif_blank(m.product_color),
    staging.nullif_blank(m.product_size),
    staging.nullif_blank(m.product_description),
    NULLIF(m.product_rating, '')::NUMERIC(4, 1),
    NULLIF(m.product_reviews, '')::INTEGER,
    staging.parse_us_date(m.product_release_date),
    staging.parse_us_date(m.product_expiry_date),
    cat.category_sk,
    br.brand_sk,
    mat.material_sk,
    sup.supplier_sk
FROM staging.mock_data m
JOIN dw.dim_product_category cat
  ON cat.product_category = COALESCE(staging.nullif_blank(m.product_category), 'Unknown')
 AND cat.pet_category = COALESCE(staging.nullif_blank(m.pet_category), 'Unknown')
JOIN dw.dim_brand br
  ON br.brand_name = COALESCE(staging.nullif_blank(m.product_brand), 'Unknown')
JOIN dw.dim_material mat
  ON mat.material_name = COALESCE(staging.nullif_blank(m.product_material), 'Unknown')
LEFT JOIN dw.dim_supplier sup
  ON sup.supplier_name = staging.nullif_blank(m.supplier_name)
 AND sup.supplier_email IS NOT DISTINCT FROM staging.nullif_blank(m.supplier_email)
WHERE staging.nullif_blank(m.product_name) IS NOT NULL
ORDER BY
    staging.nullif_blank(m.product_name),
    br.brand_sk,
    cat.category_sk,
    m.load_id
ON CONFLICT (product_name, brand_sk, category_sk) DO NOTHING;

INSERT INTO dw.dim_customer (
    first_name, last_name, age, email,
    pet_type, pet_name, pet_breed, postal_sk
)
SELECT DISTINCT ON (staging.nullif_blank(m.customer_email))
    staging.nullif_blank(m.customer_first_name),
    staging.nullif_blank(m.customer_last_name),
    NULLIF(m.customer_age, '')::INTEGER,
    staging.nullif_blank(m.customer_email),
    staging.nullif_blank(m.customer_pet_type),
    staging.nullif_blank(m.customer_pet_name),
    staging.nullif_blank(m.customer_pet_breed),
    p.postal_sk
FROM staging.mock_data m
LEFT JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.customer_country)
LEFT JOIN dw.dim_postal_code p
  ON p.postal_code = staging.nullif_blank(m.customer_postal_code)
 AND p.country_sk = c.country_sk
WHERE staging.nullif_blank(m.customer_email) IS NOT NULL
ORDER BY staging.nullif_blank(m.customer_email), m.load_id
ON CONFLICT (email) DO NOTHING;

INSERT INTO dw.dim_seller (
    first_name, last_name, email, postal_sk
)
SELECT DISTINCT ON (staging.nullif_blank(m.seller_email))
    staging.nullif_blank(m.seller_first_name),
    staging.nullif_blank(m.seller_last_name),
    staging.nullif_blank(m.seller_email),
    p.postal_sk
FROM staging.mock_data m
LEFT JOIN dw.dim_country c
  ON c.country_name = staging.nullif_blank(m.seller_country)
LEFT JOIN dw.dim_postal_code p
  ON p.postal_code = staging.nullif_blank(m.seller_postal_code)
 AND p.country_sk = c.country_sk
WHERE staging.nullif_blank(m.seller_email) IS NOT NULL
ORDER BY staging.nullif_blank(m.seller_email), m.load_id
ON CONFLICT (email) DO NOTHING;

INSERT INTO dw.dim_store (
    store_name, store_location, store_phone, store_email, city_sk
)
SELECT DISTINCT ON (
    staging.nullif_blank(m.store_name),
    staging.nullif_blank(m.store_location),
    staging.nullif_blank(m.store_phone)
)
    staging.nullif_blank(m.store_name),
    staging.nullif_blank(m.store_location),
    staging.nullif_blank(m.store_phone),
    staging.nullif_blank(m.store_email),
    ci.city_sk
FROM staging.mock_data m
LEFT JOIN dw.dim_country co
  ON co.country_name = staging.nullif_blank(m.store_country)
LEFT JOIN dw.dim_region r
  ON r.region_name = staging.nullif_blank(m.store_state)
 AND r.country_sk = co.country_sk
LEFT JOIN dw.dim_city ci
  ON ci.city_name = staging.nullif_blank(m.store_city)
 AND ci.country_sk = co.country_sk
 AND ci.region_sk IS NOT DISTINCT FROM r.region_sk
WHERE staging.nullif_blank(m.store_name) IS NOT NULL
ORDER BY
    staging.nullif_blank(m.store_name),
    staging.nullif_blank(m.store_location),
    staging.nullif_blank(m.store_phone),
    m.load_id
ON CONFLICT (store_name, store_location, store_phone) DO NOTHING;

INSERT INTO dw.dim_date (
    date_sk, full_date, year, quarter, month, day, day_of_week, month_name, is_weekend
)
SELECT DISTINCT
    TO_CHAR(d.full_date, 'YYYYMMDD')::INTEGER,
    d.full_date,
    EXTRACT(YEAR FROM d.full_date)::SMALLINT,
    EXTRACT(QUARTER FROM d.full_date)::SMALLINT,
    EXTRACT(MONTH FROM d.full_date)::SMALLINT,
    EXTRACT(DAY FROM d.full_date)::SMALLINT,
    EXTRACT(ISODOW FROM d.full_date)::SMALLINT,
    TO_CHAR(d.full_date, 'TMMonth'),
    EXTRACT(ISODOW FROM d.full_date) IN (6, 7)
FROM (
    SELECT staging.parse_us_date(sale_date) AS full_date
    FROM staging.mock_data
    WHERE staging.parse_us_date(sale_date) IS NOT NULL
) d
ON CONFLICT (date_sk) DO NOTHING;
