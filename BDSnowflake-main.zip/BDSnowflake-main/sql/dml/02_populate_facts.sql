INSERT INTO dw.fact_sales (
    load_id,
    source_file,
    source_sale_id,
    date_sk,
    customer_sk,
    seller_sk,
    product_sk,
    store_sk,
    sale_quantity,
    sale_total_price,
    unit_price
)
SELECT
    m.load_id,
    m.source_file,
    m.id,
    TO_CHAR(staging.parse_us_date(m.sale_date), 'YYYYMMDD')::INTEGER,
    c.customer_sk,
    s.seller_sk,
    p.product_sk,
    st.store_sk,
    COALESCE(NULLIF(m.sale_quantity, '')::INTEGER, 0),
    COALESCE(NULLIF(m.sale_total_price, '')::NUMERIC(12, 2), 0),
    NULLIF(m.product_price, '')::NUMERIC(12, 2)
FROM staging.mock_data m
JOIN dw.dim_customer c
  ON c.email = staging.nullif_blank(m.customer_email)
JOIN dw.dim_seller s
  ON s.email = staging.nullif_blank(m.seller_email)
JOIN dw.dim_product_category cat
  ON cat.product_category = COALESCE(staging.nullif_blank(m.product_category), 'Unknown')
 AND cat.pet_category = COALESCE(staging.nullif_blank(m.pet_category), 'Unknown')
JOIN dw.dim_brand br
  ON br.brand_name = COALESCE(staging.nullif_blank(m.product_brand), 'Unknown')
JOIN dw.dim_product p
  ON p.product_name = staging.nullif_blank(m.product_name)
 AND p.category_sk = cat.category_sk
 AND p.brand_sk = br.brand_sk
JOIN dw.dim_store st
  ON st.store_name IS NOT DISTINCT FROM staging.nullif_blank(m.store_name)
 AND st.store_location IS NOT DISTINCT FROM staging.nullif_blank(m.store_location)
 AND st.store_phone IS NOT DISTINCT FROM staging.nullif_blank(m.store_phone)
WHERE staging.parse_us_date(m.sale_date) IS NOT NULL;
