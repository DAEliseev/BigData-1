docker compose up -d

while ($true) {
    if (docker compose logs postgres 2>$null | Select-String "Database initialization complete") {
        break
    }
    Start-Sleep -Seconds 3
}

docker exec -it bdsnowflake-postgres psql -U labuser -d petshop_dw

docker compose down
