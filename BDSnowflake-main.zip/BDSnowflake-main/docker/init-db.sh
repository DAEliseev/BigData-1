#!/bin/bash
set -euo pipefail

echo "Creating staging table..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -f /sql/ddl/01_staging.sql

echo "Loading CSV source files..."
for file in /data/csv/*.csv; do
  [ -f "$file" ] || continue
  filename=$(basename "$file")
  echo "  -> ${filename}"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    COPY staging.mock_data_raw
    FROM '${file}'
    WITH (FORMAT csv, HEADER true, DELIMITER ',', QUOTE '"', ESCAPE '"', ENCODING 'UTF8');

    INSERT INTO staging.mock_data (
      source_file, id, customer_first_name, customer_last_name, customer_age,
      customer_email, customer_country, customer_postal_code, customer_pet_type,
      customer_pet_name, customer_pet_breed, seller_first_name, seller_last_name,
      seller_email, seller_country, seller_postal_code, product_name, product_category,
      product_price, product_quantity, sale_date, sale_customer_id, sale_seller_id,
      sale_product_id, sale_quantity, sale_total_price, store_name, store_location,
      store_city, store_state, store_country, store_phone, store_email, pet_category,
      product_weight, product_color, product_size, product_brand, product_material,
      product_description, product_rating, product_reviews, product_release_date,
      product_expiry_date, supplier_name, supplier_contact, supplier_email,
      supplier_phone, supplier_address, supplier_city, supplier_country
    )
    SELECT
      '${filename}', id, customer_first_name, customer_last_name, customer_age,
      customer_email, customer_country, customer_postal_code, customer_pet_type,
      customer_pet_name, customer_pet_breed, seller_first_name, seller_last_name,
      seller_email, seller_country, seller_postal_code, product_name, product_category,
      product_price, product_quantity, sale_date, sale_customer_id, sale_seller_id,
      sale_product_id, sale_quantity, sale_total_price, store_name, store_location,
      store_city, store_state, store_country, store_phone, store_email, pet_category,
      product_weight, product_color, product_size, product_brand, product_material,
      product_description, product_rating, product_reviews, product_release_date,
      product_expiry_date, supplier_name, supplier_contact, supplier_email,
      supplier_phone, supplier_address, supplier_city, supplier_country
    FROM staging.mock_data_raw;

    TRUNCATE staging.mock_data_raw;
EOSQL
done

mock_count=$(psql -t -A --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -c "SELECT COUNT(*) FROM staging.mock_data;")
echo "Loaded ${mock_count} rows into staging.mock_data"

echo "Creating data warehouse (snowflake schema)..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -f /sql/ddl/02_dw_snowflake.sql

echo "Populating dimensions and facts..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -f /sql/dml/01_populate_dimensions.sql
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -f /sql/dml/02_populate_facts.sql

echo "Verification:"
psql --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
  SELECT 'staging.mock_data' AS object_name, COUNT(*)::text AS row_count FROM staging.mock_data
  UNION ALL
  SELECT 'dw.fact_sales', COUNT(*)::text FROM dw.fact_sales
  UNION ALL
  SELECT 'dw.dim_customer', COUNT(*)::text FROM dw.dim_customer
  UNION ALL
  SELECT 'dw.dim_product', COUNT(*)::text FROM dw.dim_product;
EOSQL

echo "Database initialization complete."
